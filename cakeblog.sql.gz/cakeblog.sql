-- phpMyAdmin SQL Dump
-- version 4.3.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 21. Dez 2014 um 23:25
-- Server-Version: 5.6.20
-- PHP-Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `cakeblog`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(75) COLLATE utf8_bin DEFAULT NULL,
  `body` text COLLATE utf8_bin,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tabelle für seocakes/cakeblog';

--
-- TRUNCATE Tabelle vor dem Einfügen `posts`
--

TRUNCATE TABLE `posts`;
--
-- Daten für Tabelle `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created`, `modified`) VALUES
(1, 'Testpost1', 'Ein Post zum testen der Ausgabe...', '2014-12-19 00:00:00', '2014-12-19 00:10:00'),
(2, 'Blog2Log', 'Eintrag Nummer Zwei\r\nHier wurde die Funktionalität unseres Cake-Blogs dahingehend erweitert, dass nun auch neue Posts hinzugefügt werden können.', '2014-12-21 23:07:46', '2014-12-21 23:07:46'),
(3, 'Blog3r', 'Der Blogg3R\r\nWeitere Info vom Blogger, dieser Post wurde mit Einbeziehung des Session-Helpers realisiert. Nach dem Absenden des Posts sollte dem Nutzer eine Benachrichtigung angezeigt werden, evtl auch eine Redirect zur index()...', '2014-12-21 23:09:59', '2014-12-21 23:09:59'),
(4, 'Blog3r', 'Der Blogg3R\r\nWeitere Info vom Blogger, dieser Post wurde mit Einbeziehung des Session-Helpers realisiert. Nach dem Absenden des Posts sollte dem Nutzer eine Benachrichtigung angezeigt werden, evtl auch eine Redirect zur index()...', '2014-12-21 23:11:14', '2014-12-21 23:11:14'),
(5, 'asdas', 'asdadfasfasd', '2014-12-21 23:11:36', '2014-12-21 23:11:36'),
(6, 'Der naechste Eintrag', 'duesma aba mit session in components', '2014-12-21 23:12:27', '2014-12-21 23:12:27'),
(7, 'awrwtr', 'awrawrar', '2014-12-21 23:14:29', '2014-12-21 23:14:29'),
(8, 'Nummer 8', 'Hier ist der Inhalt des achten Eintrags unserers CakeBl0g5', '2014-12-21 23:15:53', '2014-12-21 23:15:53'),
(9, 'wqw twetzg ewrh ad', 'qweqweqwr', '2014-12-21 23:19:13', '2014-12-21 23:19:13');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
